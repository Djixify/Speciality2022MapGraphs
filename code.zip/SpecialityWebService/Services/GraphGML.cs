﻿namespace SpecialityWebService.Services
{
    public class GraphGML
    {
        public string File { get; set; }
        public GraphGML(string fileout)
        {
            File = fileout;
        }
    }
}
